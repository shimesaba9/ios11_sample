//
//  ViewController.swift
//  CoreMLSample
//
//  Created by 杉本裕樹 on 2017/08/26.
//  Copyright © 2017年 cl. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController {
    let imageView = UIImageView()
    let resultLabel = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 0.98, green: 0.98, blue: 0.98, alpha: 1)
        
        imageView.backgroundColor = UIColor.gray
        imageView.frame = CGRect(x: (view.frame.width - 240) / 2, y: 20, width: 240, height: 240)
        view.addSubview(imageView)
        
        let selectBtn = UIButton(frame: CGRect(x: 0, y: view.frame.height - 44, width: view.frame.width, height: 44))
        selectBtn.addTarget(self, action: #selector(self.tapSelectBtn), for: .touchUpInside)
        selectBtn.setTitle("画像選択", for: .normal)
        selectBtn.setTitleColor(.white, for: .normal)
        selectBtn.backgroundColor = .darkGray
        view.addSubview(selectBtn)
        
        resultLabel.frame = CGRect(x: (view.frame.width - 240) / 2, y: imageView.frame.maxY, width: 240, height: 200)
        resultLabel.numberOfLines = 0
        view.addSubview(resultLabel)
    }
    
    @objc func tapSelectBtn() {
        let c = UIImagePickerController()
        c.delegate = self
        present(c, animated: true)
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage, let model = try? VNCoreMLModel(for: MobileNet().model) {
            imageView.image = image
            picker.dismiss(animated: true, completion: nil)
            
            let request = VNCoreMLRequest(model: model) { request, error in
                guard let results = request.results as? [VNClassificationObservation] else {
                    return
                }
                let resultStrs = results.map { "\($0.identifier): \(NSString(format: "%.2f", $0.confidence))" }.prefix(5)
                self.resultLabel.text = "● 解析結果\n" + resultStrs.joined(separator: "\n")
            }
            request.imageCropAndScaleOption = .centerCrop
            let handler = VNImageRequestHandler(cgImage: image.cgImage!)
            try! handler.perform([request])
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

