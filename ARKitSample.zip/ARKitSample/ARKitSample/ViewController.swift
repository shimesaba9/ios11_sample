//
//  ViewController.swift
//  ARKitSample
//
//  Created by 杉本裕樹 on 2017/08/17.
//  Copyright © 2017年 cl. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate {
    @IBOutlet var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        sceneView.debugOptions = ARSCNDebugOptions.showFeaturePoints
        sceneView.scene = SCNScene()
        
        sceneView.addGestureRecognizer(UITapGestureRecognizer(
            target: self, action: #selector(self.tapView(sender:))))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        sceneView.session.pause()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else {
            return
        }
        
        let box = SCNBox(width: 0.1, height: 0.1, length: 0.05, chamferRadius: 0.01)
        let planeNode = SCNNode(geometry: box)
        planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
        planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2, 1, 0, 0)
        
        node.addChildNode(planeNode)
        let material = SCNMaterial()
        material.diffuse.contents = UIColor(red: 0.85, green: 0.95, blue: 0.85, alpha:1.00)
        let sideMaterial = SCNMaterial()
        sideMaterial.diffuse.contents = UIColor(red: 0.55, green: 0.57, blue: 0.55, alpha: 1.00)
        
        planeNode.geometry?.materials = [material, sideMaterial]
    }
    
    @objc func tapView(sender: UITapGestureRecognizer) {
        let tapPoint = sender.location(in: sceneView)
        
        let results = sceneView.hitTest(tapPoint, types: .existingPlaneUsingExtent)
        results.forEach {
            guard let anchor = $0.anchor else { return }
            let node = sceneView.node(for: anchor)
            let action = SCNAction.rotateBy(x: 10, y: 0, z: 0, duration: 2.0)
            node?.childNodes.first?.runAction(action)
        }
    }
}
